package com.example.aplikasi_pulau_indonesia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
